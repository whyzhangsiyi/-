#include <iostream>
#include "StrVec.h"

int main()
{


    StrVec strvec1;

    string s("sfds");

    strvec1.push_back(s);
    StrVec strvec2(strvec1);
    for (int i = 0; i <10 ; ++i)
    {
        strvec2.push_back(s);
    }

    for (auto  i = strvec2.begin(); i != strvec2.end(); ++i)
    {

        cout<<*i<<ends;
    }
    strvec1=strvec2;

    strvec1.push_back(s);
    cout<<strvec2.size()<<ends<<strvec2.capacity()<<endl;
    cout<<strvec1.size()<<ends<<strvec1.capacity()<<endl;
    std::cout << "Hello, World!" << std::endl;
    return 0;
}


//add